<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
	<?php
		session_start();
		$usuarios = [[
        			'nome' => 'usuario1',
        			'email' => 'usuario1@gmail.com',
       				 'senha' => 'a8XkP2zq'
			],
    			[
        			'nome' => 'usuario2',
        			'email' => 'usuario2@yahoo.com',
       				'senha' => 'Lm9vT7sE'
    			],
    			[
        			'nome' => 'usuario3',
        			'email' => 'usuario3@hotmail.com',
        			'senha' => 'Pq4rZ1wL'
    			]
		];
		$i = 0;
		$email = $_POST["email"];
		$senha = $_POST["senha"];
echo !isset($_SESSION['usuarios']);
		if(!isset($_SESSION['usuarios'])){
echo "teste";
			for($i=0;$i<count($usuarios);$i++){
echo $i;
				if(($usuarios[$i]['email'] == $email) && ($usuarios[$i]['senha'] == $senha)) {
					$_SESSION['usuarios'] = [
						'nome' => $usuarios[$i]['nome'],
						'email' => $usuarios[$i]['email'],
						'senha' => $usuarios[$i]['senha']
					];
					break;
				}
echo "teste";
			}
		}
		if(isset($_SESSION['usuarios'])){
			echo "Bem Vindo " . $_SESSION['usuarios']['nome'];
		}
		else echo "Login Invalido"
	?>
</body>
</html>